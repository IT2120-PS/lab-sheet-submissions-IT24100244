setwd("C:\\Users\\IT24100244\\Desktop\\IT24100244")

branch_data<-read.table("Exercise.txt",header = TRUE)
fix(branch_data)
attach(branch_data)

summary(Branch)
summary(Sales_X1)
summary(Advertising_X2)
summary(Years_X3)

boxplot(Sales_X1,main="boxplot for sales", ylab="Sales")

quantile(Advertising_X2)
IQR(Advertising_X2)

get.outliers_years<-function(c){
  q1<-quantile(c)[2]
  q3<-quantile(c)[4]
  iqr<-q3-q1
  
  ub<-q3+1.5*iqr
  lb<-q1-1.5*iqr
  
  print(paste("Upper bound= ",ub))
  print(paste("Lower bound= ",lb))
  
}

get.outliers_years(Years_X3)